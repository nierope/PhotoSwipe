using PhotoSwipe.Models;
using PhotoSwipe.Services;

namespace PhotoSwipe.Tests;

/// <summary>Creates a temporary folder with dummy photo files and removes it afterwards.</summary>
public sealed class TempFolder : IDisposable
{
    public string Path { get; } = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "PhotoSwipeTests_" + Guid.NewGuid().ToString("N"));

    public TempFolder(params string[] files)
    {
        Directory.CreateDirectory(Path);
        foreach (string file in files)
        {
            File.WriteAllText(System.IO.Path.Combine(Path, file), file);
        }
    }

    public string Combine(params string[] parts) => System.IO.Path.Combine(new[] { Path }.Concat(parts).ToArray());

    public void Dispose() => Directory.Delete(Path, recursive: true);
}

public class PhotoQueueTests
{
    [Fact]
    public void FromFolder_ListsOnlySupportedTopLevelPhotosInNameOrder()
    {
        using var folder = new TempFolder("b.JPG", "a.png", "notes.txt", "c.webp");
        Directory.CreateDirectory(folder.Combine("save"));
        File.WriteAllText(folder.Combine("save", "nested.jpg"), "x");

        var queue = PhotoQueue.FromFolder(folder.Path);

        Assert.Equal("a.png", Path.GetFileName(queue.Current));
        Assert.Equal(3, queue.Total);
        queue.Advance();
        Assert.Equal("b.JPG", Path.GetFileName(queue.Current));
        queue.Advance();
        Assert.Equal("c.webp", Path.GetFileName(queue.Current));
        queue.Advance();
        Assert.True(queue.IsEmpty);
        Assert.Null(queue.Current);
    }

    [Fact]
    public void Reinsert_PutsPhotoBackInFront()
    {
        var queue = new PhotoQueue(new[] { "1.jpg", "2.jpg" });
        queue.Advance();
        queue.Reinsert("1.jpg");

        Assert.Equal("1.jpg", queue.Current);
        Assert.Equal(1, queue.Position);
        Assert.Equal(2, queue.Total);
    }

    [Fact]
    public void FromFolder_MissingFolder_Throws() =>
        Assert.Throws<DirectoryNotFoundException>(() => PhotoQueue.FromFolder(@"Z:\does\not\exist"));
}

public class SortSessionTests
{
    private static readonly SwipeRule Save = SwipeRule.MoveTo("save");
    private static readonly SwipeRule Delete = SwipeRule.MoveTo("delete");

    [Fact]
    public void Apply_MovesFileToRuleFolderAndAdvances()
    {
        using var folder = new TempFolder("a.jpg", "b.jpg");
        var session = new SortSession(folder.Path);

        session.Apply(Save);
        session.Apply(Delete);

        Assert.True(File.Exists(folder.Combine("save", "a.jpg")));
        Assert.True(File.Exists(folder.Combine("delete", "b.jpg")));
        Assert.Null(session.Current);
        Assert.Empty(Directory.GetFiles(folder.Path));
    }

    [Fact]
    public void Apply_NameClash_AddsSuffixInsteadOfOverwriting()
    {
        using var folder = new TempFolder("a.jpg");
        Directory.CreateDirectory(folder.Combine("save"));
        File.WriteAllText(folder.Combine("save", "a.jpg"), "existing");

        new SortSession(folder.Path).Apply(Save);

        Assert.Equal("existing", File.ReadAllText(folder.Combine("save", "a.jpg")));
        Assert.True(File.Exists(folder.Combine("save", "a (1).jpg")));
    }

    [Fact]
    public void Apply_NeverRemovesFiles_EveryPhotoEndsUpInATargetFolder()
    {
        using var folder = new TempFolder("a.jpg", "b.jpg", "c.jpg");
        var session = new SortSession(folder.Path);

        session.Apply(Save);
        session.Apply(Delete);
        session.Apply(Delete);

        string[] all = Directory.GetFiles(folder.Path, "*", SearchOption.AllDirectories);
        Assert.Equal(3, all.Length);
        Assert.Single(Directory.GetFiles(folder.Combine("save")));
        Assert.Equal(2, Directory.GetFiles(folder.Combine("delete")).Length);
    }

    [Fact]
    public void Undo_RestoresFileAndMakesItCurrentAgain()
    {
        using var folder = new TempFolder("a.jpg", "b.jpg");
        var session = new SortSession(folder.Path);
        session.Apply(Save);

        Assert.True(session.CanUndo);
        session.Undo();

        Assert.True(File.Exists(folder.Combine("a.jpg")));
        Assert.False(File.Exists(folder.Combine("save", "a.jpg")));
        Assert.Equal("a.jpg", Path.GetFileName(session.Current));
        Assert.Equal(1, session.Position);
        Assert.False(session.CanUndo);
    }

    [Fact]
    public void Undo_SupportsMultipleStepsInReverseOrder()
    {
        using var folder = new TempFolder("a.jpg", "b.jpg");
        var session = new SortSession(folder.Path);
        session.Apply(Save);
        session.Apply(Delete);

        session.Undo();
        Assert.Equal("b.jpg", Path.GetFileName(session.Current));
        session.Undo();
        Assert.Equal("a.jpg", Path.GetFileName(session.Current));
    }

    [Fact]
    public void Apply_TargetEqualsSource_ThrowsAndKeepsState()
    {
        using var folder = new TempFolder("a.jpg");
        var session = new SortSession(folder.Path);

        Assert.Throws<InvalidOperationException>(() => session.Apply(SwipeRule.MoveTo(".")));

        Assert.Equal("a.jpg", Path.GetFileName(session.Current));
        Assert.True(File.Exists(folder.Combine("a.jpg")));
    }

    [Fact]
    public void DiscardCurrent_SkipsFileWithoutTouchingIt()
    {
        using var folder = new TempFolder("a.jpg", "b.jpg");
        var session = new SortSession(folder.Path);

        session.DiscardCurrent();

        Assert.Equal("b.jpg", Path.GetFileName(session.Current));
        Assert.Equal(1, session.Total);
        Assert.True(File.Exists(folder.Combine("a.jpg")));
    }
}

public class SwipeRuleTests
{
    [Theory]
    [InlineData("save", null)]
    [InlineData("sorted\\keep", null)]
    [InlineData(@"D:\Photos\keep", null)]
    [InlineData("", "Enter a folder name.")]
    [InlineData("   ", "Enter a folder name.")]
    public void Validate_ReportsEmptyNames(string name, string? expected) =>
        Assert.Equal(expected, SwipeRule.MoveTo(name).Validate());

    [Theory]
    [InlineData("sa*ve")]
    [InlineData("a?b")]
    [InlineData("..\\outside")]
    [InlineData("c:evil")]
    public void Validate_RejectsInvalidNames(string name) =>
        Assert.NotNull(SwipeRule.MoveTo(name).Validate());

    [Fact]
    public void Settings_RejectIdenticalFolders()
    {
        var settings = new AppSettings { LeftRule = SwipeRule.MoveTo("Keep"), RightRule = SwipeRule.MoveTo("keep\\") };
        Assert.NotNull(settings.Validate());
    }

    [Fact]
    public void StampText_WithoutLabel_UsesLastFolderNameInUpperCase() =>
        Assert.Equal("KEEP", SwipeRule.MoveTo(@"D:\Photos\keep").StampText);

    [Fact]
    public void StampText_WithLabel_UsesLabel() =>
        Assert.Equal("ARCHIVE", SwipeRule.MoveTo("delete", "Archive").StampText);

    [Fact]
    public void Validate_RejectsTooLongLabel() =>
        Assert.NotNull(SwipeRule.MoveTo("x", new string('a', SwipeRule.MaxLabelLength + 1)).Validate());

    [Fact]
    public void Defaults_AreSaveAndDelete()
    {
        var settings = new AppSettings();
        Assert.Equal("SAVE", settings.LeftRule.StampText);
        Assert.Equal("DELETE", settings.RightRule.StampText);
    }
}

public class SettingsServiceTests
{
    [Fact]
    public void SaveThenLoad_RoundTripsSettings()
    {
        using var folder = new TempFolder();
        var service = new SettingsService(folder.Combine("settings.json"));
        var settings = new AppSettings
        {
            SourceFolder = @"C:\Photos",
            LeftRule = SwipeRule.MoveTo("keep"),
            RightRule = SwipeRule.MoveTo("old", "Archive"),
            ZoomMode = ZoomMode.Percent,
            ZoomPercent = 200
        };

        Assert.True(service.Save(settings));
        AppSettings loaded = service.Load();

        Assert.Equal(@"C:\Photos", loaded.SourceFolder);
        Assert.Equal("keep", loaded.LeftRule.FolderName);
        Assert.Equal("Archive", loaded.RightRule.Label);
        Assert.Equal(ZoomMode.Percent, loaded.ZoomMode);
        Assert.Equal(200, loaded.ZoomPercent);
    }

    [Fact]
    public void Load_SettingsFromOlderVersionWithActionField_StillLoads()
    {
        using var folder = new TempFolder();
        string path = folder.Combine("settings.json");
        File.WriteAllText(path, """{ "LeftRule": { "FolderName": "keep", "Action": "SendToRecycleBin" } }""");

        AppSettings loaded = new SettingsService(path).Load();

        Assert.Equal("keep", loaded.LeftRule.FolderName);
        Assert.Equal("KEEP", loaded.LeftRule.StampText);
        Assert.Equal("delete", loaded.RightRule.FolderName);
    }

    [Fact]
    public void Load_CorruptFile_ReturnsDefaults()
    {
        using var folder = new TempFolder();
        string path = folder.Combine("settings.json");
        File.WriteAllText(path, "{ not json");

        AppSettings loaded = new SettingsService(path).Load();

        Assert.Equal("save", loaded.LeftRule.FolderName);
        Assert.Equal("delete", loaded.RightRule.FolderName);
    }
}

public class ImageLoaderTests
{
    [Fact]
    public void Load_ReadsPngAndDoesNotLockTheFile()
    {
        using var folder = new TempFolder();
        string path = folder.Combine("test.png");
        using (var source = new System.Drawing.Bitmap(40, 20))
        {
            source.Save(path, System.Drawing.Imaging.ImageFormat.Png);
        }

        using System.Drawing.Bitmap loaded = ImageLoader.Load(path);
        File.Move(path, folder.Combine("moved.png")); // would throw if the file were still locked

        Assert.Equal(40, loaded.Width);
        Assert.Equal(20, loaded.Height);
    }

    [Fact]
    public void Load_NotAnImage_ThrowsInvalidData()
    {
        using var folder = new TempFolder("fake.jpg");
        Assert.Throws<InvalidDataException>(() => ImageLoader.Load(folder.Combine("fake.jpg")));
    }
}
