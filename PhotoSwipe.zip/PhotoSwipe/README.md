# Photo Swipe

A WinForms (.NET 9) tool to sort photos Tinder-style. Pick a folder, then swipe each photo
**left** (default: moved to `save`) or **right** (default: moved to `delete`).
The next photo appears until the source folder is empty.

## Run

```
dotnet run --project src/PhotoSwipe
```

## Use

| Action | Mouse | Keyboard |
|---|---|---|
| Swipe left | drag the photo to the left | `←` |
| Swipe right | drag the photo to the right | `→` |
| Undo last swipe | Edit ▸ Undo | `↑` or `Ctrl+Z` |
| Select folder | File ▸ Select photo folder… | `Ctrl+O` |
| Reload folder | File ▸ Reload folder | `F5` |

* **Zoom** menu: Fit, Fill, 25 / 50 / 100 / 200 / 400 %.
* **Settings ▸ Swipe actions…**: per direction choose the **folder** (a name relative to the photo
  folder, or a full path) and the **label** shown on the photo while swiping (e.g. `Delete`,
  later `Archive`; empty = folder name).
* **Photos are never deleted**: a swipe only moves the file into the configured folder. Nothing is
  overwritten and nothing goes to the Recycle Bin.
* Only the top level of the folder is scanned. Supported: JPG, JPEG, PNG, BMP, GIF, TIFF, WEBP
  (WebP needs the Windows "WebP Image Extensions", included in Windows 11).
* A thumbnail of the next photo is shown at the bottom.
* Existing files are never overwritten: a clash becomes `name (1).jpg`.
* Undo moves the file back and works for any number of steps.
* Settings are stored in `%AppData%\PhotoSwipe\settings.json`.

## Structure

```
src/PhotoSwipe
├─ Models/     SwipeRule, SwipeResult, ZoomMode, AppSettings
├─ Services/   SortSession (queue + file ops + undo), PhotoQueue, PhotoFileHandler,
│              ImageLoader (no file lock, EXIF rotation, WebP via WIC), SettingsService
├─ Controls/   PhotoCard – custom-drawn swipeable card (drag, tilt, fly-off animation)
└─ Forms/      MainForm, SettingsForm
tests/PhotoSwipe.Tests   xUnit tests for the logic layer
```

The UI contains no file logic: `MainForm` only talks to `SortSession`, which is unit-tested.
