using System;
using System.Drawing;
using System.Windows.Forms;
using PhotoSwipe.Models;

namespace PhotoSwipe.Forms;

/// <summary>Dialog in which the user configures what happens on a left and a right swipe.</summary>
public sealed class SettingsForm : Form
{
    private readonly RuleEditor _leftEditor;
    private readonly RuleEditor _rightEditor;

    /// <summary>Creates the dialog with the current rules (copies are edited; originals stay untouched until OK).</summary>
    public SettingsForm(SwipeRule leftRule, SwipeRule rightRule)
    {
        Text = "Swipe settings";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.CenterParent;
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;

        _leftEditor = new RuleEditor("Swipe left  (← key)", leftRule);
        _rightEditor = new RuleEditor("Swipe right  (→ key)", rightRule);

        var ok = new Button { Text = "OK", AutoSize = true, MinimumSize = new Size(90, 0) };
        ok.Click += OnOkClicked;
        var cancel = new Button { Text = "Cancel", AutoSize = true, MinimumSize = new Size(90, 0), DialogResult = DialogResult.Cancel };

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft,
            AutoSize = true
        };
        buttons.Controls.Add(cancel);
        buttons.Controls.Add(ok);

        var layout = new TableLayoutPanel
        {
            ColumnCount = 1,
            AutoSize = true,
            Padding = new Padding(12),
            Dock = DockStyle.Fill
        };
        layout.Controls.Add(_leftEditor);
        layout.Controls.Add(_rightEditor);
        layout.Controls.Add(buttons);
        Controls.Add(layout);

        AcceptButton = ok;
        CancelButton = cancel;

        LeftRule = leftRule;
        RightRule = rightRule;
    }

    /// <summary>The edited rule for the left swipe (valid after the dialog returned OK).</summary>
    public SwipeRule LeftRule { get; private set; }

    /// <summary>The edited rule for the right swipe (valid after the dialog returned OK).</summary>
    public SwipeRule RightRule { get; private set; }

    private void OnOkClicked(object? sender, EventArgs e)
    {
        var candidate = new AppSettings { LeftRule = _leftEditor.GetRule(), RightRule = _rightEditor.GetRule() };
        string? error = candidate.Validate();
        if (error is not null)
        {
            MessageBox.Show(this, error, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        LeftRule = candidate.LeftRule;
        RightRule = candidate.RightRule;
        DialogResult = DialogResult.OK;
    }

    /// <summary>Group box with the controls for one <see cref="SwipeRule"/>.</summary>
    private sealed class RuleEditor : GroupBox
    {
        private readonly TextBox _label = new() { Dock = DockStyle.Fill, MaxLength = SwipeRule.MaxLabelLength };
        private readonly TextBox _folder = new() { Dock = DockStyle.Fill };

        public RuleEditor(string title, SwipeRule rule)
        {
            Text = title;
            AutoSize = true;
            Padding = new Padding(10);
            Dock = DockStyle.Fill;

            _label.Text = rule.Label;
            _folder.Text = rule.FolderName;
            _folder.MinimumSize = new Size(300, 0);

            var hint = new Label
            {
                Text = "Label: text shown on the photo while swiping (e.g. Delete, Archive). Empty = folder name.\n"
                       + "Folder: a name relative to the photo folder (e.g. save) or a full path.\n"
                       + "Photos are only moved to this folder, never deleted.",
                AutoSize = true,
                ForeColor = SystemColors.GrayText
            };

            var layout = new TableLayoutPanel { ColumnCount = 2, AutoSize = true, Dock = DockStyle.Fill };
            layout.Controls.Add(new Label { Text = "Label:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
            layout.Controls.Add(_label, 1, 0);
            layout.Controls.Add(new Label { Text = "Folder:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 1);
            layout.Controls.Add(_folder, 1, 1);
            layout.Controls.Add(hint, 1, 2);
            Controls.Add(layout);
        }

        /// <summary>Builds a rule from the current input.</summary>
        public SwipeRule GetRule() => SwipeRule.MoveTo(_folder.Text.Trim(), _label.Text.Trim());
    }
}
