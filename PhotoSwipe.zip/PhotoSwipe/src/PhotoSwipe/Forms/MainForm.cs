using System;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using PhotoSwipe.Controls;
using PhotoSwipe.Models;
using PhotoSwipe.Services;

namespace PhotoSwipe.Forms;

/// <summary>
/// Main window: menu, the swipeable <see cref="PhotoCard"/>, a preview of the next photo and a status bar.
/// Contains only UI wiring; all sorting logic lives in <see cref="SortSession"/>.
/// </summary>
public sealed class MainForm : Form
{
    /// <summary>The zoom entries of the Zoom menu.</summary>
    private static readonly (string Text, ZoomMode Mode, int Percent)[] ZoomChoices =
    {
        ("Fit to frame", ZoomMode.Fit, 0),
        ("Fill frame", ZoomMode.Fill, 0),
        ("25 %", ZoomMode.Percent, 25),
        ("50 %", ZoomMode.Percent, 50),
        ("100 %", ZoomMode.Percent, 100),
        ("200 %", ZoomMode.Percent, 200),
        ("400 %", ZoomMode.Percent, 400)
    };

    private const int ThumbnailSize = 220;

    private readonly SettingsService _settingsService = new();
    private readonly AppSettings _settings;

    private readonly PhotoCard _card = new() { Dock = DockStyle.Fill };
    private readonly PictureBox _thumbnail = new() { Dock = DockStyle.Fill, SizeMode = PictureBoxSizeMode.Zoom };
    private readonly ToolStripStatusLabel _fileLabel = new() { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
    private readonly ToolStripStatusLabel _progressLabel = new();
    private readonly ToolStripStatusLabel _rulesLabel = new();
    private ToolStripMenuItem[] _zoomItems = Array.Empty<ToolStripMenuItem>();

    private SortSession? _session;
    private Bitmap? _currentBitmap;
    private PendingLoad? _preload;
    private int _showVersion;

    /// <summary>A photo (plus thumbnail) that is being, or has been, loaded in the background.</summary>
    private sealed record PendingLoad(string Path, Task<LoadedPhoto> Task);

    /// <summary>Result of a background load. <see cref="Image"/> is <c>null</c> when the file is unreadable.</summary>
    private sealed record LoadedPhoto(Bitmap? Image, Bitmap? Thumbnail);

    /// <summary>Creates the main window.</summary>
    public MainForm()
    {
        _settings = _settingsService.Load();

        Text = "Photo Swipe";
        ClientSize = new Size(1100, 780);
        MinimumSize = new Size(640, 480);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(30, 30, 34);
        ForeColor = Color.Gainsboro;

        BuildLayout();
        ApplySettingsToUi();

        _card.SwipeCompleted += OnCardSwipeCompleted;
        Shown += async (_, _) => await OpenInitialFolderAsync();
        FormClosing += (_, _) => _settingsService.Save(_settings);
    }

    #region UI construction

    private void BuildLayout()
    {
        // Docking order: controls added last are docked first, so the fill control goes in first.
        Controls.Add(_card);
        Controls.Add(BuildBottomPanel());
        Controls.Add(BuildStatusStrip());
        MenuStrip menu = BuildMenu();
        Controls.Add(menu);
        MainMenuStrip = menu;
    }

    private MenuStrip BuildMenu()
    {
        var selectFolder = new ToolStripMenuItem("Select photo &folder…", null, async (_, _) => await ChooseFolderAsync())
        {
            ShortcutKeys = Keys.Control | Keys.O
        };
        var reload = new ToolStripMenuItem("&Reload folder", null, async (_, _) => await ReloadAsync())
        {
            ShortcutKeys = Keys.F5
        };
        var exit = new ToolStripMenuItem("E&xit", null, (_, _) => Close());
        var file = new ToolStripMenuItem("&File");
        file.DropDownItems.AddRange(new ToolStripItem[] { selectFolder, reload, new ToolStripSeparator(), exit });

        var undo = new ToolStripMenuItem("&Undo last swipe", null, async (_, _) => await UndoAsync())
        {
            ShortcutKeys = Keys.Control | Keys.Z
        };
        var edit = new ToolStripMenuItem("&Edit");
        edit.DropDownItems.Add(undo);

        var zoom = new ToolStripMenuItem("&Zoom");
        _zoomItems = new ToolStripMenuItem[ZoomChoices.Length];
        for (int i = 0; i < ZoomChoices.Length; i++)
        {
            (string text, ZoomMode mode, int percent) = ZoomChoices[i];
            var item = new ToolStripMenuItem(text, null, (_, _) => SetZoom(mode, percent));
            _zoomItems[i] = item;
            zoom.DropDownItems.Add(item);
        }

        var swipeSettings = new ToolStripMenuItem("&Swipe actions…", null, (_, _) => ShowSettingsDialog());
        var settings = new ToolStripMenuItem("&Settings");
        settings.DropDownItems.Add(swipeSettings);

        var menu = new MenuStrip();
        menu.Items.AddRange(new ToolStripItem[] { file, edit, zoom, settings });
        return menu;
    }

    private StatusStrip BuildStatusStrip()
    {
        var status = new StatusStrip();
        status.Items.AddRange(new ToolStripItem[] { _fileLabel, _progressLabel, _rulesLabel });
        return status;
    }

    private Panel BuildBottomPanel()
    {
        var caption = new Label
        {
            Text = "Next photo",
            Dock = DockStyle.Top,
            AutoSize = true,
            ForeColor = Color.Silver
        };
        var thumbnailHost = new Panel { Dock = DockStyle.Left, Width = ThumbnailSize + 20, Padding = new Padding(4) };
        thumbnailHost.Controls.Add(_thumbnail);
        thumbnailHost.Controls.Add(caption);

        var hint = new Label
        {
            Text = "←  /  →  swipe left / right (or drag the photo with the mouse)        ↑  or  Ctrl+Z  undo",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.Silver
        };

        var panel = new Panel { Dock = DockStyle.Bottom, Height = (int)(ThumbnailSize * 0.62) + 30 };
        panel.Controls.Add(hint);
        panel.Controls.Add(thumbnailHost);
        return panel;
    }

    #endregion

    #region Keyboard

    /// <summary>Handles the arrow keys before child controls or menus can swallow them.</summary>
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        switch (keyData)
        {
            case Keys.Left:
                _card.Swipe(SwipeDirection.Left);
                return true;
            case Keys.Right:
                _card.Swipe(SwipeDirection.Right);
                return true;
            case Keys.Up:
                UndoFromKey();
                return true;
            default:
                return base.ProcessCmdKey(ref msg, keyData);
        }
    }

    private async void UndoFromKey() => await UndoAsync();

    #endregion

    #region Folder handling

    private async Task OpenInitialFolderAsync()
    {
        if (Directory.Exists(_settings.SourceFolder))
        {
            await OpenFolderAsync(_settings.SourceFolder);
        }
        else
        {
            ShowIdleMessage("Choose a photo folder with  File ▸ Select photo folder…  (Ctrl+O)");
        }
    }

    private async Task ChooseFolderAsync()
    {
        using var dialog = new FolderBrowserDialog
        {
            Description = "Select the folder that contains the photos to sort",
            UseDescriptionForTitle = true,
            SelectedPath = _settings.SourceFolder
        };

        if (dialog.ShowDialog(this) == DialogResult.OK)
        {
            await OpenFolderAsync(dialog.SelectedPath);
        }
    }

    private async Task ReloadAsync()
    {
        if (!string.IsNullOrEmpty(_settings.SourceFolder))
        {
            await OpenFolderAsync(_settings.SourceFolder);
        }
    }

    private async Task OpenFolderAsync(string folder)
    {
        try
        {
            _session = new SortSession(folder);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            _session = null;
            MessageBox.Show(this, ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            ShowIdleMessage("The folder could not be opened.");
            return;
        }

        _settings.SourceFolder = folder;
        _settingsService.Save(_settings);
        _preload = null;
        Text = $"Photo Swipe – {folder}";
        await ShowCurrentAsync();
    }

    #endregion

    #region Showing photos

    /// <summary>
    /// Displays the session's current photo (skipping unreadable files) or the "finished" message.
    /// A version counter makes sure only the most recent call updates the UI.
    /// </summary>
    private async Task ShowCurrentAsync(string? notice = null)
    {
        int version = ++_showVersion;

        while (_session is { Current: { } path } session)
        {
            LoadedPhoto photo = await GetPhotoAsync(path);
            if (version != _showVersion)
            {
                photo.Image?.Dispose();
                photo.Thumbnail?.Dispose();
                return;
            }

            photo.Thumbnail?.Dispose(); // the thumbnail of the photo we now show in full is not needed

            if (photo.Image is null)
            {
                notice = $"Skipped unreadable file: {Path.GetFileName(path)}";
                session.DiscardCurrent();
                continue;
            }

            SetCurrentBitmap(photo.Image);
            UpdateStatus(notice);
            _ = PreloadNextAsync();
            return;
        }

        SetCurrentBitmap(null);
        SetThumbnail(null);
        _preload = null;
        ShowIdleMessage(_session is null
            ? "Choose a photo folder with  File ▸ Select photo folder…  (Ctrl+O)"
            : _session.Total == 0
                ? "No photos (JPG, PNG, BMP, GIF, TIFF, WEBP) found in this folder."
                : "All photos have been processed. The folder is empty.\n\nPress ↑ or Ctrl+Z to undo the last swipe.",
            notice);
    }

    /// <summary>Returns the preloaded photo if it matches, otherwise loads it now (off the UI thread).</summary>
    private Task<LoadedPhoto> GetPhotoAsync(string path)
    {
        if (_preload is { } preload && preload.Path == path)
        {
            _preload = null;
            return preload.Task;
        }

        return Task.Run(() => LoadPhoto(path, createThumbnail: false));
    }

    /// <summary>Starts loading the upcoming photo in the background and shows its thumbnail when ready.</summary>
    private async Task PreloadNextAsync()
    {
        string? next = _session?.Next;
        if (next is null)
        {
            _preload = null;
            SetThumbnail(null);
            return;
        }

        var pending = new PendingLoad(next, Task.Run(() => LoadPhoto(next, createThumbnail: true)));
        _preload = pending;
        SetThumbnail(null);

        LoadedPhoto photo = await pending.Task;
        if (!ReferenceEquals(_preload, pending))
        {
            // Superseded or already consumed as the current photo; only the thumbnail is ours to discard.
            photo.Thumbnail?.Dispose();
            return;
        }

        SetThumbnail(photo.Thumbnail);
    }

    private static LoadedPhoto LoadPhoto(string path, bool createThumbnail)
    {
        try
        {
            Bitmap image = ImageLoader.Load(path);
            Bitmap? thumbnail = createThumbnail ? ImageLoader.CreateThumbnail(image, ThumbnailSize) : null;
            return new LoadedPhoto(image, thumbnail);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException)
        {
            return new LoadedPhoto(null, null);
        }
    }

    private void SetCurrentBitmap(Bitmap? bitmap)
    {
        Bitmap? old = _currentBitmap;
        _currentBitmap = bitmap;
        _card.Image = bitmap;
        old?.Dispose();
    }

    private void SetThumbnail(Bitmap? thumbnail)
    {
        Image? old = _thumbnail.Image;
        _thumbnail.Image = thumbnail;
        old?.Dispose();
    }

    private void ShowIdleMessage(string message, string? notice = null)
    {
        _card.EmptyMessage = message;
        _card.Invalidate();
        UpdateStatus(notice);
    }

    #endregion

    #region Swiping and undo

    private async void OnCardSwipeCompleted(object? sender, SwipeDirection direction)
    {
        if (_session?.Current is null)
        {
            return;
        }

        SwipeRule rule = direction == SwipeDirection.Left ? _settings.LeftRule : _settings.RightRule;
        try
        {
            _session.Apply(rule);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidOperationException)
        {
            _card.CancelSwipe();
            MessageBox.Show(this, ex.Message, "The photo could not be processed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        await ShowCurrentAsync();
    }

    private async Task UndoAsync()
    {
        if (_session is null || _card.IsBusy)
        {
            return;
        }

        if (!_session.CanUndo)
        {
            UpdateStatus("Nothing to undo.");
            return;
        }

        try
        {
            _session.Undo();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidOperationException)
        {
            MessageBox.Show(this, ex.Message, "Undo failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        await ShowCurrentAsync("Undone.");
    }

    #endregion

    #region Settings and zoom

    private void ShowSettingsDialog()
    {
        using var dialog = new SettingsForm(_settings.LeftRule.Clone(), _settings.RightRule.Clone());
        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }

        _settings.LeftRule = dialog.LeftRule;
        _settings.RightRule = dialog.RightRule;
        _settingsService.Save(_settings);
        ApplySettingsToUi();
        UpdateStatus();
    }

    private void SetZoom(ZoomMode mode, int percent)
    {
        _settings.ZoomMode = mode;
        if (mode == ZoomMode.Percent)
        {
            _settings.ZoomPercent = percent;
        }

        ApplySettingsToUi();
    }

    /// <summary>Pushes the current settings (rules and zoom) into the card and menu.</summary>
    private void ApplySettingsToUi()
    {
        _card.LeftLabel = _settings.LeftRule.StampText;
        _card.RightLabel = _settings.RightRule.StampText;
        _card.ZoomMode = _settings.ZoomMode;
        _card.ZoomPercent = _settings.ZoomPercent;

        for (int i = 0; i < ZoomChoices.Length; i++)
        {
            (_, ZoomMode mode, int percent) = ZoomChoices[i];
            _zoomItems[i].Checked = mode == _settings.ZoomMode
                                    && (mode != ZoomMode.Percent || percent == _settings.ZoomPercent);
        }
    }

    #endregion

    private void UpdateStatus(string? notice = null)
    {
        string? current = _session?.Current;
        _fileLabel.Text = notice ?? (current is null ? string.Empty : Path.GetFileName(current));
        _progressLabel.Text = current is null || _session is null ? string.Empty : $"Photo {_session.Position} of {_session.Total}";
        _rulesLabel.Text = $"←  {_settings.LeftRule.Describe()}     →  {_settings.RightRule.Describe()}";
    }

    /// <inheritdoc />
    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _currentBitmap?.Dispose();
            _thumbnail.Image?.Dispose();
        }

        base.Dispose(disposing);
    }
}
