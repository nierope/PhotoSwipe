using System.IO;
using System.Linq;

namespace PhotoSwipe.Models;

/// <summary>
/// Configuration of one swipe direction: the folder the photo is moved to and the
/// text shown on the card while swiping. Photos are only ever moved, never deleted.
/// </summary>
public sealed class SwipeRule
{
    /// <summary>Maximum length of <see cref="Label"/>, so it fits on the card.</summary>
    public const int MaxLabelLength = 20;

    // Characters that are never valid in a folder name. Separators and ':' are
    // handled separately because they are legal in (absolute) paths.
    private static readonly char[] InvalidChars = Path.GetInvalidFileNameChars()
        .Where(c => c is not ('\\' or '/' or ':'))
        .ToArray();

    /// <summary>
    /// Target folder. Either a name relative to the source folder (e.g. <c>save</c>)
    /// or a full path (e.g. <c>D:\Photos\keep</c>).
    /// </summary>
    public string FolderName { get; set; } = string.Empty;

    /// <summary>
    /// Text shown on the card while swiping (e.g. "Delete" or "Archive").
    /// When empty, the name of the target folder is used.
    /// </summary>
    public string Label { get; set; } = string.Empty;

    /// <summary>Creates a rule that moves photos to the given folder.</summary>
    /// <param name="folderName">Relative folder name or full path.</param>
    /// <param name="label">Text shown on the card; empty to use the folder name.</param>
    public static SwipeRule MoveTo(string folderName, string label = "") =>
        new() { FolderName = folderName, Label = label };

    /// <summary>Returns the absolute target folder for this rule.</summary>
    /// <param name="sourceFolder">The folder being sorted; relative names are resolved against it.</param>
    public string ResolveTargetFolder(string sourceFolder)
    {
        string name = FolderName.Trim();
        return Path.IsPathFullyQualified(name)
            ? Path.GetFullPath(name)
            : Path.GetFullPath(Path.Combine(sourceFolder, name));
    }

    /// <summary>The label to show: <see cref="Label"/>, or the target folder's name when no label is set.</summary>
    public string DisplayName
    {
        get
        {
            string label = Label.Trim();
            if (label.Length > 0)
            {
                return label;
            }

            string folder = FolderName.Trim().TrimEnd('\\', '/');
            string last = Path.GetFileName(folder);
            return last.Length > 0 ? last : folder;
        }
    }

    /// <summary>Upper-case text for the stamp on the card (e.g. "ARCHIVE").</summary>
    public string StampText => DisplayName.ToUpperInvariant();

    /// <summary>Short description for the status bar, e.g. "Save → 'save'".</summary>
    public string Describe() => $"{DisplayName} → '{FolderName.Trim()}'";

    /// <summary>Checks the rule and returns an error message, or <c>null</c> when it is valid.</summary>
    public string? Validate()
    {
        if (Label.Trim().Length > MaxLabelLength)
        {
            return $"The label may be at most {MaxLabelLength} characters.";
        }

        string name = FolderName.Trim();
        if (name.Length == 0)
        {
            return "Enter a folder name.";
        }

        if (name.IndexOfAny(InvalidChars) >= 0)
        {
            return $"The folder name '{name}' contains invalid characters.";
        }

        if (Path.IsPathFullyQualified(name))
        {
            return null;
        }

        // Neither a full path nor a plain relative name: "\folder" and "c:folder" depend on the current directory.
        if (Path.IsPathRooted(name))
        {
            return @"Use a full path (e.g. D:\Photos\keep) or a name relative to the photo folder.";
        }

        if (name.Contains(':') || name.Split('\\', '/').Contains(".."))
        {
            return "A relative folder name may not contain ':' or '..'.";
        }

        return null;
    }

    /// <summary>Creates an independent copy of this rule.</summary>
    public SwipeRule Clone() => new() { FolderName = FolderName, Label = Label };
}
