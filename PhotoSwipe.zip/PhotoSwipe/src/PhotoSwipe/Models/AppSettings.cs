using System;

namespace PhotoSwipe.Models;

/// <summary>User settings that are persisted between sessions.</summary>
public sealed class AppSettings
{
    /// <summary>The folder that is currently being sorted (empty when none was chosen yet).</summary>
    public string SourceFolder { get; set; } = string.Empty;

    /// <summary>Rule applied when a photo is swiped to the left. Default: move to "save".</summary>
    public SwipeRule LeftRule { get; set; } = SwipeRule.MoveTo("save", "Save");

    /// <summary>Rule applied when a photo is swiped to the right. Default: move to "delete" (labelled "Delete").</summary>
    public SwipeRule RightRule { get; set; } = SwipeRule.MoveTo("delete", "Delete");

    /// <summary>How photos are scaled in the frame.</summary>
    public ZoomMode ZoomMode { get; set; } = ZoomMode.Fit;

    /// <summary>Percentage used when <see cref="ZoomMode"/> is <see cref="ZoomMode.Percent"/>.</summary>
    public int ZoomPercent { get; set; } = 100;

    /// <summary>
    /// Validates both rules and checks that they do not target the same folder.
    /// Returns an error message, or <c>null</c> when the settings are valid.
    /// </summary>
    public string? Validate()
    {
        string? error = LeftRule.Validate() ?? RightRule.Validate();
        if (error is not null)
        {
            return error;
        }

        if (string.Equals(Normalize(LeftRule.FolderName), Normalize(RightRule.FolderName),
                StringComparison.OrdinalIgnoreCase))
        {
            return "Left and right must use different folders.";
        }

        return null;
    }

    private static string Normalize(string folder) => folder.Trim().TrimEnd('\\', '/');
}
