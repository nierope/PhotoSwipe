namespace PhotoSwipe.Models;

/// <summary>The direction in which a photo is swiped.</summary>
public enum SwipeDirection
{
    /// <summary>Swipe to the left.</summary>
    Left,

    /// <summary>Swipe to the right.</summary>
    Right
}
