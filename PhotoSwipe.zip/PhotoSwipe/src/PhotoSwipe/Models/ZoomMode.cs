namespace PhotoSwipe.Models;

/// <summary>How a photo is scaled inside the photo frame.</summary>
public enum ZoomMode
{
    /// <summary>Scale so the whole photo is visible (letterboxed).</summary>
    Fit,

    /// <summary>Scale so the photo covers the whole frame (edges may be cropped).</summary>
    Fill,

    /// <summary>Use a fixed percentage, see <see cref="AppSettings.ZoomPercent"/>.</summary>
    Percent
}
