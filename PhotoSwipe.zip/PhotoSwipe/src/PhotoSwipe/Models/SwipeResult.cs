namespace PhotoSwipe.Models;

/// <summary>Describes where a photo was moved to by a swipe, so the move can be reverted.</summary>
/// <param name="OriginalPath">Full path of the photo before the swipe.</param>
/// <param name="NewPath">Full path of the photo in the target folder.</param>
public sealed record SwipeResult(string OriginalPath, string NewPath);
