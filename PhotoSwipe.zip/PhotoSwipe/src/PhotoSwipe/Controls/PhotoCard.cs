using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;
using PhotoSwipe.Models;

namespace PhotoSwipe.Controls;

/// <summary>
/// Large "card" that shows one photo and can be swiped left or right, either by dragging
/// with the mouse or by calling <see cref="Swipe"/> (used for the arrow keys).
/// </summary>
/// <remarks>
/// Life cycle of a swipe: <c>Idle</c> → <c>Dragging</c> → <c>FlyingOut</c> → <c>Awaiting</c>.
/// In <c>Awaiting</c> the card is invisible and <see cref="SwipeCompleted"/> has been raised; the host
/// then assigns the next <see cref="Image"/> (which resets the card) or calls <see cref="CancelSwipe"/>.
/// A drag that is released too early goes through <c>SnappingBack</c> instead.
/// </remarks>
public sealed class PhotoCard : Control
{
    private enum MotionState { Idle, Dragging, FlyingOut, SnappingBack, Awaiting }

    /// <summary>Fraction of the control width the card must be dragged before a release counts as a swipe.</summary>
    private const float SwipeThreshold = 0.22f;

    /// <summary>Tilt (degrees) of the card when it is dragged half the control width.</summary>
    private const float MaxTiltDegrees = 14f;

    private static readonly Color LeftColor = Color.MediumSeaGreen;
    private static readonly Color RightColor = Color.IndianRed;

    private readonly System.Windows.Forms.Timer _animationTimer = new() { Interval = 15 };
    private readonly Font _stampFont;
    private readonly Font _messageFont;

    private Bitmap? _image;
    private MotionState _state = MotionState.Idle;
    private Point _dragStart;
    private float _offsetX;
    private float _offsetY;
    private float _velocity;
    private SwipeDirection _flyDirection;
    private ZoomMode _zoomMode = ZoomMode.Fit;
    private int _zoomPercent = 100;

    /// <summary>Raised after the card has flown off screen. The host should process the photo and show the next one.</summary>
    public event EventHandler<SwipeDirection>? SwipeCompleted;

    /// <summary>Creates the card.</summary>
    public PhotoCard()
    {
        SetStyle(
            ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw,
            true);

        BackColor = Color.FromArgb(30, 30, 34);
        ForeColor = Color.Gainsboro;
        _stampFont = new Font(FontFamily.GenericSansSerif, 26f, FontStyle.Bold);
        _messageFont = new Font(FontFamily.GenericSansSerif, 14f, FontStyle.Regular);
        _animationTimer.Tick += OnAnimationTick;
    }

    /// <summary>
    /// The photo to display. Assigning a value resets any swipe animation. The card does not take
    /// ownership: the caller is responsible for disposing the bitmap after replacing it.
    /// </summary>
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Bitmap? Image
    {
        get => _image;
        set
        {
            _image = value;
            ResetMotion();
            Cursor = value is null ? Cursors.Default : Cursors.Hand;
            Invalidate();
        }
    }

    /// <summary>How the photo is scaled inside the frame.</summary>
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public ZoomMode ZoomMode
    {
        get => _zoomMode;
        set { _zoomMode = value; Invalidate(); }
    }

    /// <summary>Zoom percentage used with <see cref="Models.ZoomMode.Percent"/>.</summary>
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int ZoomPercent
    {
        get => _zoomPercent;
        set { _zoomPercent = Math.Clamp(value, 5, 800); Invalidate(); }
    }

    /// <summary>Text shown on the card while it is swiped to the left.</summary>
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public string LeftLabel { get; set; } = string.Empty;

    /// <summary>Text shown on the card while it is swiped to the right.</summary>
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public string RightLabel { get; set; } = string.Empty;

    /// <summary>Message displayed when there is no photo.</summary>
    [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public string EmptyMessage { get; set; } = string.Empty;

    /// <summary>True while the user drags the card or an animation is running.</summary>
    public bool IsBusy => _state is MotionState.Dragging or MotionState.FlyingOut or MotionState.SnappingBack;

    /// <summary>Animates the card off screen in the given direction (keyboard alternative to dragging).</summary>
    public void Swipe(SwipeDirection direction)
    {
        if (_image is null || _state != MotionState.Idle)
        {
            return;
        }

        BeginFlyOut(direction);
    }

    /// <summary>Brings a card that already flew off screen back (used when processing the photo failed).</summary>
    public void CancelSwipe()
    {
        if (_state == MotionState.Awaiting)
        {
            _state = MotionState.SnappingBack;
            _animationTimer.Start();
            Invalidate();
        }
    }

    #region Mouse handling

    /// <inheritdoc />
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button == MouseButtons.Left && _image is not null && _state == MotionState.Idle)
        {
            _state = MotionState.Dragging;
            _dragStart = e.Location;
        }
    }

    /// <inheritdoc />
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (_state == MotionState.Dragging)
        {
            _offsetX = e.X - _dragStart.X;
            _offsetY = (e.Y - _dragStart.Y) * 0.5f; // vertical movement is dampened; the swipe is horizontal
            Invalidate();
        }
    }

    /// <inheritdoc />
    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (_state != MotionState.Dragging)
        {
            return;
        }

        if (Math.Abs(_offsetX) > Width * SwipeThreshold)
        {
            BeginFlyOut(_offsetX < 0 ? SwipeDirection.Left : SwipeDirection.Right);
        }
        else
        {
            _state = MotionState.SnappingBack;
            _animationTimer.Start();
        }
    }

    #endregion

    #region Animation

    private void BeginFlyOut(SwipeDirection direction)
    {
        _flyDirection = direction;
        _velocity = Width * 0.03f;
        _state = MotionState.FlyingOut;
        _animationTimer.Start();
    }

    private void ResetMotion()
    {
        _animationTimer.Stop();
        _offsetX = 0;
        _offsetY = 0;
        _state = MotionState.Idle;
    }

    private void OnAnimationTick(object? sender, EventArgs e)
    {
        switch (_state)
        {
            case MotionState.FlyingOut:
                // Accelerate away from the centre until the card is completely off screen.
                _velocity += Width * 0.01f;
                _offsetX += (_flyDirection == SwipeDirection.Left ? -1 : 1) * _velocity;
                if (Math.Abs(_offsetX) > Width)
                {
                    _animationTimer.Stop();
                    _state = MotionState.Awaiting;
                    SwipeCompleted?.Invoke(this, _flyDirection);
                }

                break;

            case MotionState.SnappingBack:
                // Ease back to the centre.
                _offsetX *= 0.7f;
                _offsetY *= 0.7f;
                if (Math.Abs(_offsetX) < 1f && Math.Abs(_offsetY) < 1f)
                {
                    ResetMotion();
                }

                break;

            default:
                _animationTimer.Stop();
                break;
        }

        Invalidate();
    }

    #endregion

    #region Painting

    /// <inheritdoc />
    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.Clear(BackColor);

        if (_image is null)
        {
            DrawMessage(g);
            return;
        }

        if (_state == MotionState.Awaiting)
        {
            return; // card is off screen; wait for the next photo
        }

        float margin = 16f * DeviceDpi / 96f;
        float frameWidth = Width - 2 * margin;
        float frameHeight = Height - 2 * margin;
        if (frameWidth < 20 || frameHeight < 20)
        {
            return;
        }

        // Cheap interpolation while the card moves keeps dragging smooth with very large photos.
        bool moving = _state != MotionState.Idle;
        g.InterpolationMode = moving ? InterpolationMode.Bilinear : InterpolationMode.HighQualityBicubic;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

        float tilt = MaxTiltDegrees * Math.Clamp(_offsetX / (Width * 0.5f), -1f, 1f);

        GraphicsState saved = g.Save();
        g.TranslateTransform(Width / 2f + _offsetX, Height / 2f + _offsetY);
        g.RotateTransform(tilt);

        var frame = new RectangleF(-frameWidth / 2, -frameHeight / 2, frameWidth, frameHeight);
        using GraphicsPath frameShape = CreateRoundedRectangle(frame, 20f);

        using (var backdrop = new SolidBrush(Color.FromArgb(14, 14, 16)))
        {
            g.FillPath(backdrop, frameShape);
        }

        g.SetClip(frameShape);
        g.DrawImage(_image, CalculateImageBounds(frame));

        float strength = Math.Clamp(Math.Abs(_offsetX) / (Width * SwipeThreshold), 0f, 1f);
        if (_offsetX < 0)
        {
            DrawStamp(g, frame, LeftLabel, LeftColor, strength, onLeftSide: false);
        }
        else if (_offsetX > 0)
        {
            DrawStamp(g, frame, RightLabel, RightColor, strength, onLeftSide: true);
        }

        g.Restore(saved);

        // Draw the card outline last, without the clip, to hide the jagged clipped corners.
        saved = g.Save();
        g.TranslateTransform(Width / 2f + _offsetX, Height / 2f + _offsetY);
        g.RotateTransform(tilt);
        using var outline = new Pen(Color.FromArgb(90, 255, 255, 255), 2f);
        g.DrawPath(outline, frameShape);
        g.Restore(saved);
    }

    /// <summary>Computes where the image is drawn inside the frame for the current zoom setting (centred).</summary>
    private RectangleF CalculateImageBounds(RectangleF frame)
    {
        float imageWidth = _image!.Width;
        float imageHeight = _image.Height;

        float scale = _zoomMode switch
        {
            ZoomMode.Fit => Math.Min(frame.Width / imageWidth, frame.Height / imageHeight),
            ZoomMode.Fill => Math.Max(frame.Width / imageWidth, frame.Height / imageHeight),
            _ => _zoomPercent / 100f
        };

        float width = imageWidth * scale;
        float height = imageHeight * scale;
        return new RectangleF(frame.X + (frame.Width - width) / 2, frame.Y + (frame.Height - height) / 2, width, height);
    }

    /// <summary>Draws the tilted "SAVE"/"DELETE" style label in a corner of the card.</summary>
    private void DrawStamp(Graphics g, RectangleF frame, string text, Color color, float opacity, bool onLeftSide)
    {
        if (opacity <= 0f || string.IsNullOrEmpty(text))
        {
            return;
        }

        int alpha = (int)(255 * opacity);
        SizeF textSize = g.MeasureString(text, _stampFont);
        float boxWidth = textSize.Width + 28;
        float boxHeight = textSize.Height + 10;

        GraphicsState saved = g.Save();
        g.TranslateTransform(onLeftSide ? frame.Left + 36 : frame.Right - 36, frame.Top + 50);
        g.RotateTransform(onLeftSide ? -16f : 16f);

        var box = new RectangleF(onLeftSide ? 0 : -boxWidth, 0, boxWidth, boxHeight);
        using GraphicsPath boxShape = CreateRoundedRectangle(box, 10f);
        using var pen = new Pen(Color.FromArgb(alpha, color), 5f);
        using var brush = new SolidBrush(Color.FromArgb(alpha, color));
        g.DrawPath(pen, boxShape);
        g.DrawString(text, _stampFont, brush, box.Left + 14, box.Top + 5);
        g.Restore(saved);
    }

    private void DrawMessage(Graphics g)
    {
        if (string.IsNullOrEmpty(EmptyMessage))
        {
            return;
        }

        using var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        using var brush = new SolidBrush(ForeColor);
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
        g.DrawString(EmptyMessage, _messageFont, brush, ClientRectangle, format);
    }

    private static GraphicsPath CreateRoundedRectangle(RectangleF rect, float radius)
    {
        float d = radius * 2;
        var path = new GraphicsPath();
        path.AddArc(rect.Left, rect.Top, d, d, 180, 90);
        path.AddArc(rect.Right - d, rect.Top, d, d, 270, 90);
        path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
        path.AddArc(rect.Left, rect.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    #endregion

    /// <inheritdoc />
    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _animationTimer.Dispose();
            _stampFont.Dispose();
            _messageFont.Dispose();
        }

        base.Dispose(disposing);
    }
}
