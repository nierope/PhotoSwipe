using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using Wpf = System.Windows.Media.Imaging;
using WpfMedia = System.Windows.Media;

namespace PhotoSwipe.Services;

/// <summary>Loads photos into memory without keeping the file open, so it can be moved while shown.</summary>
public static class ImageLoader
{
    /// <summary>EXIF tag that stores the camera orientation.</summary>
    private const int ExifOrientationId = 0x0112;

    /// <summary>
    /// Loads an image, applying its EXIF orientation. GDI+ is tried first; if it cannot decode the
    /// file (e.g. WebP) the Windows Imaging Component is used instead.
    /// </summary>
    /// <returns>A bitmap that is fully independent of the file. The caller must dispose it.</returns>
    /// <exception cref="InvalidDataException">The file is not a readable image.</exception>
    public static Bitmap Load(string path)
    {
        byte[] bytes = File.ReadAllBytes(path);

        try
        {
            return LoadWithGdiPlus(bytes);
        }
        catch (Exception ex) when (ex is ArgumentException or OutOfMemoryException)
        {
            // GDI+ reports unsupported formats with these exceptions; try WIC below.
        }

        try
        {
            return LoadWithWic(bytes);
        }
        catch (Exception ex) when (ex is NotSupportedException or InvalidOperationException
                                       or System.IO.FileFormatException or ArgumentException)
        {
            throw new InvalidDataException($"'{Path.GetFileName(path)}' is not a readable image.", ex);
        }
    }

    /// <summary>Creates a scaled-down copy whose longest side is at most <paramref name="maxSize"/> pixels.</summary>
    public static Bitmap CreateThumbnail(Image source, int maxSize)
    {
        double scale = Math.Min(1.0, (double)maxSize / Math.Max(source.Width, source.Height));
        int width = Math.Max(1, (int)Math.Round(source.Width * scale));
        int height = Math.Max(1, (int)Math.Round(source.Height * scale));

        var thumbnail = new Bitmap(width, height, PixelFormat.Format32bppPArgb);
        using Graphics g = Graphics.FromImage(thumbnail);
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.DrawImage(source, 0, 0, width, height);
        return thumbnail;
    }

    private static Bitmap LoadWithGdiPlus(byte[] bytes)
    {
        using var stream = new MemoryStream(bytes);
        using Image image = Image.FromStream(stream, useEmbeddedColorManagement: false, validateImageData: true);

        RotateFlipType rotation = GetExifRotation(image);

        // Copying detaches the pixels from the stream; only the first frame of a GIF is kept.
        var copy = new Bitmap(image);
        if (rotation != RotateFlipType.RotateNoneFlipNone)
        {
            copy.RotateFlip(rotation);
        }

        return copy;
    }

    private static Bitmap LoadWithWic(byte[] bytes)
    {
        using var stream = new MemoryStream(bytes);
        Wpf.BitmapDecoder decoder = Wpf.BitmapDecoder.Create(
            stream, Wpf.BitmapCreateOptions.PreservePixelFormat, Wpf.BitmapCacheOption.OnLoad);

        Wpf.BitmapSource converted = new Wpf.FormatConvertedBitmap(
            decoder.Frames[0], WpfMedia.PixelFormats.Bgra32, null, 0);

        var bitmap = new Bitmap(converted.PixelWidth, converted.PixelHeight, PixelFormat.Format32bppArgb);
        BitmapData data = bitmap.LockBits(
            new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try
        {
            converted.CopyPixels(System.Windows.Int32Rect.Empty, data.Scan0, data.Stride * data.Height, data.Stride);
        }
        finally
        {
            bitmap.UnlockBits(data);
        }

        return bitmap;
    }

    /// <summary>Translates the EXIF orientation value into the rotation/flip needed to display it upright.</summary>
    private static RotateFlipType GetExifRotation(Image image)
    {
        if (Array.IndexOf(image.PropertyIdList, ExifOrientationId) < 0)
        {
            return RotateFlipType.RotateNoneFlipNone;
        }

        byte[]? value = image.GetPropertyItem(ExifOrientationId)?.Value;
        int orientation = value is { Length: >= 2 } ? BitConverter.ToUInt16(value, 0) : 1;

        return orientation switch
        {
            2 => RotateFlipType.RotateNoneFlipX,
            3 => RotateFlipType.Rotate180FlipNone,
            4 => RotateFlipType.Rotate180FlipX,
            5 => RotateFlipType.Rotate90FlipX,
            6 => RotateFlipType.Rotate90FlipNone,
            7 => RotateFlipType.Rotate270FlipX,
            8 => RotateFlipType.Rotate270FlipNone,
            _ => RotateFlipType.RotateNoneFlipNone
        };
    }
}
