using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using PhotoSwipe.Models;

namespace PhotoSwipe.Services;

/// <summary>Loads and saves <see cref="AppSettings"/> as a JSON file in the user's AppData folder.</summary>
public sealed class SettingsService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    /// <summary>Full path of the settings file.</summary>
    public string FilePath { get; }

    /// <summary>Creates the service.</summary>
    /// <param name="filePath">Custom settings file location; defaults to <c>%AppData%\PhotoSwipe\settings.json</c>.</param>
    public SettingsService(string? filePath = null)
    {
        FilePath = filePath ?? Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "PhotoSwipe",
            "settings.json");
    }

    /// <summary>
    /// Reads the settings. A missing or corrupt file results in default settings
    /// so the application can always start.
    /// </summary>
    public AppSettings Load()
    {
        try
        {
            if (!File.Exists(FilePath))
            {
                return new AppSettings();
            }

            using FileStream stream = File.OpenRead(FilePath);
            AppSettings settings = JsonSerializer.Deserialize<AppSettings>(stream, JsonOptions) ?? new AppSettings();

            // Guard against hand-edited files that contain explicit nulls.
            // Settings written by older versions (with an "Action" field) simply ignore it.
            var defaults = new AppSettings();
            settings.LeftRule ??= defaults.LeftRule;
            settings.RightRule ??= defaults.RightRule;
            settings.LeftRule.Label ??= string.Empty;
            settings.RightRule.Label ??= string.Empty;
            settings.LeftRule.FolderName ??= string.Empty;
            settings.RightRule.FolderName ??= string.Empty;
            settings.SourceFolder ??= string.Empty;
            return settings;
        }
        catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
        {
            return new AppSettings();
        }
    }

    /// <summary>Writes the settings to disk. Returns <c>false</c> if the file could not be written.</summary>
    public bool Save(AppSettings settings)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(settings, JsonOptions));
            return true;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return false;
        }
    }
}
