using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace PhotoSwipe.Services;

/// <summary>
/// The ordered list of photos that still have to be processed.
/// Only the top level of a folder is scanned.
/// </summary>
public sealed class PhotoQueue
{
    /// <summary>File extensions (lower case) that are treated as photos.</summary>
    public static readonly IReadOnlyList<string> SupportedExtensions =
        new[] { ".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tif", ".tiff", ".webp" };

    private readonly List<string> _pending;
    private int _processed;

    /// <summary>Creates a queue from an explicit list of file paths.</summary>
    public PhotoQueue(IEnumerable<string> files)
    {
        _pending = files.ToList();
    }

    /// <summary>Scans the top level of <paramref name="folder"/> for supported photos, ordered by file name.</summary>
    /// <exception cref="DirectoryNotFoundException">The folder does not exist.</exception>
    public static PhotoQueue FromFolder(string folder)
    {
        if (!Directory.Exists(folder))
        {
            throw new DirectoryNotFoundException($"The folder '{folder}' does not exist.");
        }

        IEnumerable<string> files = Directory
            .EnumerateFiles(folder, "*", SearchOption.TopDirectoryOnly)
            .Where(IsSupported)
            .OrderBy(Path.GetFileName, StringComparer.OrdinalIgnoreCase);

        return new PhotoQueue(files);
    }

    /// <summary>True when the file has one of the <see cref="SupportedExtensions"/>.</summary>
    public static bool IsSupported(string path) =>
        SupportedExtensions.Contains(Path.GetExtension(path), StringComparer.OrdinalIgnoreCase);

    /// <summary>The photo that is currently shown, or <c>null</c> when the queue is empty.</summary>
    public string? Current => _pending.Count > 0 ? _pending[0] : null;

    /// <summary>The photo that follows <see cref="Current"/>, or <c>null</c> when there is none.</summary>
    public string? Next => _pending.Count > 1 ? _pending[1] : null;

    /// <summary>1-based position of the current photo.</summary>
    public int Position => _processed + 1;

    /// <summary>Number of photos handled so far plus the ones still waiting.</summary>
    public int Total => _processed + _pending.Count;

    /// <summary>True when no photos are left.</summary>
    public bool IsEmpty => _pending.Count == 0;

    /// <summary>Marks the current photo as processed and moves on to the next one.</summary>
    public void Advance()
    {
        if (_pending.Count == 0)
        {
            return;
        }

        _pending.RemoveAt(0);
        _processed++;
    }

    /// <summary>Puts a previously processed photo back at the front of the queue (used by undo).</summary>
    public void Reinsert(string path)
    {
        _pending.Insert(0, path);
        if (_processed > 0)
        {
            _processed--;
        }
    }

    /// <summary>Drops the current photo without processing it (e.g. an unreadable file).</summary>
    public void DiscardCurrent()
    {
        if (_pending.Count > 0)
        {
            _pending.RemoveAt(0);
        }
    }
}
