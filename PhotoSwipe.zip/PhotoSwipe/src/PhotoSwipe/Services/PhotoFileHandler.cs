using System;
using System.IO;
using PhotoSwipe.Models;

namespace PhotoSwipe.Services;

/// <summary>
/// Moves photos according to a <see cref="SwipeRule"/> and moves them back on undo.
/// This is the only place that touches photo files, and it only ever calls <see cref="File.Move(string, string)"/>:
/// nothing is deleted, overwritten or sent to the Recycle Bin.
/// </summary>
public static class PhotoFileHandler
{
    /// <summary>Moves a photo into the rule's target folder (created when missing).</summary>
    /// <param name="filePath">The photo to move.</param>
    /// <param name="rule">The rule that names the target folder.</param>
    /// <param name="sourceFolder">The folder being sorted; relative target folders are resolved against it.</param>
    /// <returns>A <see cref="SwipeResult"/> that can be passed to <see cref="Undo"/>.</returns>
    /// <exception cref="InvalidOperationException">The target folder is the source folder itself.</exception>
    /// <exception cref="IOException">The file could not be moved (in use, no permission, ...).</exception>
    public static SwipeResult Apply(string filePath, SwipeRule rule, string sourceFolder)
    {
        string targetFolder = rule.ResolveTargetFolder(sourceFolder);
        if (IsSamePath(targetFolder, sourceFolder))
        {
            throw new InvalidOperationException(
                "The target folder is the same as the source folder. Change it in Settings.");
        }

        Directory.CreateDirectory(targetFolder);
        string destination = GetUniquePath(targetFolder, Path.GetFileName(filePath));
        File.Move(filePath, destination);
        return new SwipeResult(filePath, destination);
    }

    /// <summary>Reverts a move by putting the file back at its original location.</summary>
    /// <exception cref="FileNotFoundException">The moved file no longer exists.</exception>
    /// <exception cref="IOException">The original location is occupied by another file.</exception>
    public static void Undo(SwipeResult result)
    {
        if (!File.Exists(result.NewPath))
        {
            throw new FileNotFoundException($"'{result.NewPath}' no longer exists.", result.NewPath);
        }

        if (File.Exists(result.OriginalPath))
        {
            throw new IOException($"A file named '{Path.GetFileName(result.OriginalPath)}' already exists in the source folder.");
        }

        File.Move(result.NewPath, result.OriginalPath);
    }

    /// <summary>Returns a path in <paramref name="folder"/> that does not exist yet, adding " (1)", " (2)", ... if needed.</summary>
    public static string GetUniquePath(string folder, string fileName)
    {
        string candidate = Path.Combine(folder, fileName);
        string name = Path.GetFileNameWithoutExtension(fileName);
        string extension = Path.GetExtension(fileName);

        for (int i = 1; File.Exists(candidate); i++)
        {
            candidate = Path.Combine(folder, $"{name} ({i}){extension}");
        }

        return candidate;
    }

    private static bool IsSamePath(string a, string b) =>
        string.Equals(
            Path.TrimEndingDirectorySeparator(Path.GetFullPath(a)),
            Path.TrimEndingDirectorySeparator(Path.GetFullPath(b)),
            StringComparison.OrdinalIgnoreCase);
}
