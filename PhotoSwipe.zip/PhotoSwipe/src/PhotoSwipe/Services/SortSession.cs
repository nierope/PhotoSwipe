using System.Collections.Generic;
using PhotoSwipe.Models;

namespace PhotoSwipe.Services;

/// <summary>
/// One sorting run over a source folder. Combines the <see cref="PhotoQueue"/>,
/// the file operations and an undo history, and is independent of any UI.
/// </summary>
public sealed class SortSession
{
    private readonly PhotoQueue _queue;
    private readonly Stack<SwipeResult> _history = new();

    /// <summary>Starts a session for the photos in the top level of <paramref name="sourceFolder"/>.</summary>
    public SortSession(string sourceFolder)
    {
        SourceFolder = sourceFolder;
        _queue = PhotoQueue.FromFolder(sourceFolder);
    }

    /// <summary>The folder being sorted.</summary>
    public string SourceFolder { get; }

    /// <summary>Path of the photo to show now, or <c>null</c> when all photos are processed.</summary>
    public string? Current => _queue.Current;

    /// <summary>Path of the upcoming photo (for the thumbnail), or <c>null</c>.</summary>
    public string? Next => _queue.Next;

    /// <summary>1-based number of the current photo.</summary>
    public int Position => _queue.Position;

    /// <summary>Total number of photos in this session.</summary>
    public int Total => _queue.Total;

    /// <summary>True when the last action can be undone.</summary>
    public bool CanUndo => _history.Count > 0;

    /// <summary>Moves the current photo to the rule's folder and advances to the next one.</summary>
    /// <returns>Where the photo was moved to.</returns>
    /// <remarks>If the file operation throws, the session state is left unchanged.</remarks>
    public SwipeResult Apply(SwipeRule rule)
    {
        string current = _queue.Current
            ?? throw new System.InvalidOperationException("There is no photo left to process.");

        SwipeResult result = PhotoFileHandler.Apply(current, rule, SourceFolder);
        _queue.Advance();
        _history.Push(result);
        return result;
    }

    /// <summary>Reverts the most recent action and makes that photo current again.</summary>
    /// <remarks>If the file operation throws, the history is left unchanged.</remarks>
    public SwipeResult Undo()
    {
        SwipeResult last = _history.Peek();
        PhotoFileHandler.Undo(last);
        _history.Pop();
        _queue.Reinsert(last.OriginalPath);
        return last;
    }

    /// <summary>Skips the current photo (e.g. because it cannot be decoded) and leaves the file untouched.</summary>
    public void DiscardCurrent() => _queue.DiscardCurrent();
}
