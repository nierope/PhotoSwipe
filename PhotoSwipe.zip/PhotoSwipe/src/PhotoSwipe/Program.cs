using System;
using System.Windows.Forms;
using PhotoSwipe.Forms;

namespace PhotoSwipe;

/// <summary>Application entry point.</summary>
internal static class Program
{
    /// <summary>Starts the Photo Swipe application.</summary>
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
